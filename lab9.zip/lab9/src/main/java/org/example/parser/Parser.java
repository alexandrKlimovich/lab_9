//package org.example.parser;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.regex.Pattern;
//import java.util.stream.Collectors;
//
//public class Parser {
//    public static List<String> parseText(String text, String regex) {
//        if (text == null || regex == null) {
//            return new ArrayList<>();
//        }
//        Pattern pattern = Pattern.compile(regex);
//        return pattern.matcher(text)
//                .results()
//                .map(matchResult -> matchResult.group().replaceAll("\\s+", " ").trim())
//                .collect(Collectors.toList());
//    }
//}
package org.example.parser;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Parser {
    public static List<String> parseText(String text, String regex) {
        if (text == null || regex == null) {
            return new ArrayList<>();
        }

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(text);

        List<String> results = new ArrayList<>();

        while (matcher.find()) {
            String match = matcher.group().replaceAll("\\s+", " ").trim();
            results.add(match);
        }

        return results;
    }
}
