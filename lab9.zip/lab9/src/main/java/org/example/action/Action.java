package org.example.action;

import org.example.parser.Parser;
import org.example.valid.ValidLocale;

import java.text.NumberFormat;
import java.text.ParseException;
import java.util.List;
import java.util.Locale;

public class Action {
    public static double calcSum(String str) {
        List<String> loc = Parser.parseText(str, "\\p{Alpha}+");
        List<String> num = Parser.parseText(str, "[0-9.,\\s]+");

        double sum = 0;

        for (int i = 0; i < num.size(); i++) {
            if (ValidLocale.isValidLocale(loc.get(i))) {
                try {
                    Locale locale = new Locale(loc.get(i));
                    NumberFormat numberFormat = NumberFormat.getNumberInstance(locale);
                    double number = numberFormat.parse(num.get(i)).doubleValue();
                    sum += number;
                } catch (ParseException e) {
                    System.err.println("Invalid number: " + e.getMessage());
                }
            }
        }

        return sum;
    }

    public static double calcAvg(String str) {
        List<String> loc = Parser.parseText(str, "\\p{Alpha}+");
        List<String> num = Parser.parseText(str, "[0-9.,\\s]+");

        double sum = 0;
        int count = 0;

        for (int i = 0; i < num.size(); i++) {
            if (ValidLocale.isValidLocale(loc.get(i))) {
                try {
                    Locale locale = new Locale(loc.get(i));
                    NumberFormat numberFormat = NumberFormat.getNumberInstance(locale);
                    double number = numberFormat.parse(num.get(i)).doubleValue();
                    sum += number;
                    count++;
                } catch (ParseException e) {
                    System.err.println("Invalid number: " + e.getMessage());
                }
            }
        }

        return sum / count;
    }
}
