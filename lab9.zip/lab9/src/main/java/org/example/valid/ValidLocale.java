package org.example.valid;

public class ValidLocale {
    public static boolean isValidLocale (String loc) {
        switch (loc) {
            case ExistLocale.GERMAN, ExistLocale.ENGLISH,
                    ExistLocale.FRENCH, ExistLocale.RUSSIAN:
                return true;
        }
        return false;
    }
}
