package org.example.valid;

public class ExistLocale {
    public static final String GERMAN = "de";
    public static final String FRENCH = "fr";
    public static final String ENGLISH = "en";
    public static final String RUSSIAN = "ru";
}
