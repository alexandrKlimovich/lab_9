package org.example;

import org.example.action.Action;
import org.example.exception.InvalidNumberException;
import org.example.reader.FileReader;

import java.io.IOException;

/**
 * В символьном файле находится информация об N числах с плавающей запятой
 * с указанием локали каждого числа отдельно. Прочитать информацию из файла.
 * Проверить на корректность, то есть являются ли числа числами.
 * Преобразовать к числовым значениям и вычислить сумму и среднее значение
 * прочитанных чисел. Создать собственный класс исключения.
 * Предусмотреть обработку исключений, возникающих при нехватке памяти,
 * отсутствии самого файла по заданному адресу, отсутствии или некорректности
 * требуемой записи в файле, недопустимом значении числа
 * (выходящим за пределы максимально допустимых значений) и т.д.
 */
public class Main {
    public static void main(String[] args) {
        FileReader fileReader = new FileReader();
        String fromFile;
        fromFile = fileReader.readFromFile("input/input.txt");

        double sum = Action.calcSum(fromFile);
        System.out.println("Sum=" + sum);

        double avg = Action.calcAvg(fromFile);
        System.out.println("Avg=" + avg);
    }
}
