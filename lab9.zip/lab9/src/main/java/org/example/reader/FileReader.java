package org.example.reader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class FileReader {
    public String readFromFile(String path) {
        try {
            byte[] contentBytes = Files.readAllBytes(Path.of(path));
            String content = new String(contentBytes);
            return content;
        } catch (IOException e) {
            throw new RuntimeException("File not found or could not be read: " + e.getMessage());
        }
    }
}
